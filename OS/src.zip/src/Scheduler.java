import java.time.Clock;
import java.util.*;

public class Scheduler {
    private LinkedList<PCB> realTimeQueue = new LinkedList<>();
    private LinkedList<PCB> interactiveQueue = new LinkedList<>();
    private LinkedList<PCB> backgroundQueue = new LinkedList<>();
    private Timer timer = new Timer();
    public PCB currentlyRunning; //tracker
    private List<PCB> sleeping = new ArrayList<>(); //separate list
    // IdleProcess 전용 저장
    private PCB idleProcessPCB;


    public Scheduler() {
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                if(currentlyRunning != null) {
                    currentlyRunning.requestStop();
                }
            }
        }, 250, 250);
    }

    public int CreateProcess(UserlandProcess up, OS.PriorityType p) {
        PCB pcb = new PCB(up, p);

        if (up instanceof IdleProcess) {
            if (idleProcessPCB == null) {
                idleProcessPCB = pcb;
                pcb.start();
            }
            return pcb.getPid();
        }

        switch(p) {
            case realtime -> realTimeQueue.add(pcb);
            case interactive -> interactiveQueue.add(pcb);
            case background -> backgroundQueue.add(pcb);
        }
        pcb.start();

        if (currentlyRunning == null) {
            SwitchProcess();
        }

        SwitchProcess();

        return pcb.pid;
        //return pcb.getPid();
    }

    public void Sleep(int mills) {
        if (currentlyRunning != null) {
            //**Does using systemUTC makes debugging difficult?
            //maybe Clock.offset, or Clock fixed ... etc?
            long wakeTime = Clock.systemUTC().millis() + mills; //wake time = current time + sleep time
            currentlyRunning.setWakeTime(wakeTime); //to PCB

            sleeping.add(currentlyRunning); //standby

            currentlyRunning = null; //clear out
            SwitchProcess();
        }
    }

    public void SwitchProcess() {
        long now = Clock.systemUTC().millis();
        Iterator<PCB> it = sleeping.iterator();

        // wake sleeping processes
        while (it.hasNext()) {
            PCB p = it.next();
            if (p.getWakeTime() <= now) {
                switch (p.getPriority()) {
                    case realtime -> realTimeQueue.add(p);
                    case interactive -> interactiveQueue.add(p);
                    case background -> backgroundQueue.add(p);
                }
                it.remove();
            }
        }

        // demote / requeue currently running process if still alive
        if (currentlyRunning != null && !currentlyRunning.isDone()) {
            OS.PriorityType p = currentlyRunning.getPriority();
            currentlyRunning.incrementTimeout();

            if (currentlyRunning.getTimeoutCount() >= 5) {
                switch (p) {
                    case realtime -> currentlyRunning.setPriority(OS.PriorityType.interactive);
                    case interactive -> currentlyRunning.setPriority(OS.PriorityType.background);
                    case background -> {}
                }
                currentlyRunning.resetTimeout();
            }

            switch (currentlyRunning.getPriority()) {
                case realtime -> realTimeQueue.add(currentlyRunning);
                case interactive -> interactiveQueue.add(currentlyRunning);
                case background -> backgroundQueue.add(currentlyRunning);
            }
        }

        // now pick next process
        Random rand = new Random();
        currentlyRunning = null;

        if (!realTimeQueue.isEmpty()) {
            int roll = rand.nextInt(10); // 0~9
            if (roll < 6) {                            // 60%
                currentlyRunning = realTimeQueue.removeFirst();
            } else if (roll < 9 && !interactiveQueue.isEmpty()) { // 30%
                currentlyRunning = interactiveQueue.removeFirst();
            } else if (!backgroundQueue.isEmpty()) {   // 10%
                currentlyRunning = backgroundQueue.removeFirst();
            } else if (!interactiveQueue.isEmpty()) {  // fallback
                currentlyRunning = interactiveQueue.removeFirst();
            } else {                                   // fallback
                currentlyRunning = realTimeQueue.removeFirst();
            }
        } else if (!interactiveQueue.isEmpty()) {
            int roll = rand.nextInt(4); // 0~3
            if (roll < 3) {             // 75%
                currentlyRunning = interactiveQueue.removeFirst();
            } else if (!backgroundQueue.isEmpty()) {
                currentlyRunning = backgroundQueue.removeFirst();
            } else {                    // fallback
                currentlyRunning = interactiveQueue.removeFirst();
            }
        } else if (!backgroundQueue.isEmpty()) {
            currentlyRunning = backgroundQueue.removeFirst();
        } else if (idleProcessPCB != null) {
            currentlyRunning = idleProcessPCB;
        }

        // debugging log
        if (currentlyRunning != null) {
           System.out.println("[SwitchProcess] Picked PID=" +
                    currentlyRunning.getPid() + " (" + currentlyRunning.getPriority() + ")");
            //currentlyRunning.start();
        } else {
            System.out.println("[SwitchProcess] Picked null (no process)");
        }
    }


    /*public void SwitchProcess() {
        //task switch
        long now = Clock.systemUTC().millis();
        Iterator<PCB> it = sleeping.iterator();

        //check sleep queue
        while (it.hasNext()) {
            PCB p = it.next();
            if (p.getWakeTime() <= now) {
                switch (p.getPriority()) {
                    case realtime -> realTimeQueue.add(p);
                    case interactive -> interactiveQueue.add(p);
                    case background -> backgroundQueue.add(p);
                }
                it.remove();
            }
        }
        System.out.println("[SwitchProcess] Queues: RT=" + realTimeQueue.size()
                + " INT=" + interactiveQueue.size()
                + " BG=" + backgroundQueue.size());

        //terminate current running process
        if (currentlyRunning != null && !currentlyRunning.isDone()) {
            OS.PriorityType p = currentlyRunning.getPriority();
            currentlyRunning.incrementTimeout();

            //demote for fairness
            if (currentlyRunning.getTimeoutCount() >= 5) {
                switch(p) {
                    case realtime -> currentlyRunning.setPriority(OS.PriorityType.interactive);
                    case interactive -> currentlyRunning.setPriority(OS.PriorityType.background);
                    case background -> {}
                }
                currentlyRunning.resetTimeout();
            }

            switch(p) {
                case realtime -> realTimeQueue.add(currentlyRunning);
                case interactive -> interactiveQueue.add(currentlyRunning);
                case background -> backgroundQueue.add(currentlyRunning);
            }
        }

        //select new process based on possibility
        //**maybe can be done by helper method ..? how?
        Random rand = new Random();
        currentlyRunning = null;

        if(!realTimeQueue.isEmpty()) {
            int roll = rand.nextInt(10); //0~9
            if (roll < 6) { //60%
                currentlyRunning = realTimeQueue.removeFirst();
            } else if (roll < 9 && !interactiveQueue.isEmpty()) {
                currentlyRunning = interactiveQueue.removeFirst();
            } else if (!backgroundQueue.isEmpty()) {
                currentlyRunning = backgroundQueue.removeFirst();
            }
        } else if (!interactiveQueue.isEmpty()) {
            int roll = rand.nextInt(4); //0~3
            if (roll < 3) { //75%
                currentlyRunning = interactiveQueue.removeFirst();
            } else if (!backgroundQueue.isEmpty()) {
                currentlyRunning = backgroundQueue.removeFirst();
            }
        } else if (!backgroundQueue.isEmpty()) {
            currentlyRunning = backgroundQueue.removeFirst();
        }

        if (!realTimeQueue.isEmpty() || !interactiveQueue.isEmpty() || !backgroundQueue.isEmpty()) {
            int roll = rand.nextInt(10);

            if (!realTimeQueue.isEmpty() && roll < 6) {          // 60%
                currentlyRunning = realTimeQueue.removeFirst();
            } else if (!interactiveQueue.isEmpty() && roll < 9) { // 30%
                currentlyRunning = interactiveQueue.removeFirst();
            } else if (!backgroundQueue.isEmpty()) {              // 10%
                currentlyRunning = backgroundQueue.removeFirst();
            }
        }
    }*/

    private PCB removeFirstQueue() {
        if (!realTimeQueue.isEmpty()) {
            return realTimeQueue.removeFirst();
        } else if (!interactiveQueue.isEmpty()) {
            return interactiveQueue.removeFirst();
        } else if (!backgroundQueue.isEmpty()) {
            return backgroundQueue.removeFirst();
        } else if (idleProcessPCB != null) {
            return idleProcessPCB;
        }
        return null;
    }

    public void exitCurrentProcess() {
        if (currentlyRunning != null) {
            //currentlyRunning.timeoutCount = 0;
            System.out.println("[Exit] Terminating PID=" + currentlyRunning.getPid());
            currentlyRunning.stop();
            currentlyRunning = null;

        }


        currentlyRunning = removeFirstQueue();

        if (currentlyRunning != null) {
            System.out.println("[SwitchProcess] Picked PID=" +
                    currentlyRunning.getPid() + " (" + currentlyRunning.getPriority() + ")");
        } else {
            System.out.println("[SwitchProcess] Picked null (no process)");
        }

        SwitchProcess();

    }
}
