public class Kernel extends Process  {
    private Scheduler scheduler;

    public Kernel() {
        super();
        scheduler = new Scheduler();
    }

    //accessor!
    public Scheduler getScheduler() {
        return scheduler;
    }

    @Override
    public void main() {
            while (true) { // Warning on infinite loop is OK...
                System.out.println("Kernel loop tick, currentCall=" + OS.currentCall);

                switch (OS.currentCall) { // get a job from OS, do it
                    case CreateProcess ->  // Note how we get parameters from OS and set the return value
                            OS.retVal = CreateProcess((UserlandProcess) OS.parameters.get(0), (OS.PriorityType) OS.parameters.get(1));
                    case SwitchProcess -> scheduler.SwitchProcess();

                    // Priority Scheduler
                    case Sleep -> Sleep((int) OS.parameters.get(0));
                    case GetPID -> OS.retVal = GetPid();
                    case Exit -> {
                        Exit();
                        OS.retVal = 0;
                    }
                    /*
                    // Devices
                    case Open ->
                    case Close ->
                    case Read ->
                    case Seek ->
                    case Write ->
                    // Messages
                    case GetPIDByName ->
                    case SendMessage ->
                    case WaitForMessage ->
                    // Memory
                    case GetMapping ->
                    case AllocateMemory ->
                    case FreeMemory ->
                     */
                }
                // TODO: Now that we have done the work asked of us, start some process then go to sleep.
                /*if (scheduler.currentlyRunning != null) {
                    scheduler.currentlyRunning.start();
                }*/
                /*if (scheduler.currentlyRunning != null && !scheduler.currentlyRunning.isDone()) {
                   scheduler.currentlyRunning.start();
                }*/

                this.stop();
            }
    }

    private void SwitchProcess() {
        scheduler.SwitchProcess();
    }

    // For assignment 1, you can ignore the priority. We will use that in assignment 2
    private int CreateProcess(UserlandProcess up, OS.PriorityType priority) {
        return scheduler.CreateProcess(up, priority);
    }

    private void Sleep(int mills) {
        scheduler.Sleep(mills);
    }

    private void Exit() {
        scheduler.exitCurrentProcess();
    }

    private int GetPid() {
        if (scheduler.currentlyRunning != null) {
            return scheduler.currentlyRunning.getPid();
        }
        return -1;
    }

    private int Open(String s) {
        return 0; // change this
    }

    private void Close(int id) {
    }

    private byte[] Read(int id, int size) {
        return null; // change this
    }

    private void Seek(int id, int to) {
    }

    private int Write(int id, byte[] data) {
        return 0; // change this
    }

    private void SendMessage(/*KernelMessage km*/) {
    }

    private KernelMessage WaitForMessage() {
        return null;
    }

    private int GetPidByName(String name) {
        return 0; // change this
    }

    private void GetMapping(int virtualPage) {
    }

    private int AllocateMemory(int size) {
        return 0; // change this
    }

    private boolean FreeMemory(int pointer, int size) {
        return true;
    }

    private void FreeAllMemory(PCB currentlyRunning) {
    }

}